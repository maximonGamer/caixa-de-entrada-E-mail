document.getElementById("entrar-btn").addEventListener("click", function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário
    validarLogin();
});

function validarLogin() {
    var email = document.getElementById("email").value;
    var senha = document.getElementById("password").value;

    if (email === "claudio.ribeiro03@cs.brazcubas.edu.br" && senha === "admin") {
        exibirMensagem("Parabéns, você logou!");
        window.location.href = "Caixa de entrada/caixa.html"; // Redireciona para a página de caixa de entrada
    } else {
        exibirMensagem("Usuário não cadastrado.");
    }
}

function exibirMensagem(mensagem) {
    alert(mensagem);
}
