const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');

const app = express();
const port = 3306;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configurando a conexão com o banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // seu usuário do MySQL
    password: 'password', // sua senha do MySQL
    database: 'biblioteca'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao banco de dados MySQL.');
});

// Rota para servir o formulário HTML
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Rota para cadastrar usuário
app.post('/cadastro', (req, res) => {
    const { name, email, phone, CPF, password } = req.body;
    
    const sql = 'INSERT INTO usuarios (name, email, phone, CPF, password) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [name, email, phone, CPF, password], (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send('Erro ao cadastrar usuário.');
        } else {
            console.log('Usuário cadastrado com sucesso.');

            // Configurando o envio de e-mail
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'seuemail@gmail.com',
                    pass: 'suasenha'
                }
            });

            const mailOptions = {
                from: 'seuemail@gmail.com',
                to: email,
                subject: 'Bem-vindo!',
                text: 'Obrigado por se cadastrar!'
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.log(error);
                    res.status(500).send('Erro ao enviar e-mail.');
                } else {
                    console.log('E-mail enviado: ' + info.response);
                    res.status(200).send('Usuário cadastrado e e-mail enviado.');
                }
            });
        }
    });
});

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
