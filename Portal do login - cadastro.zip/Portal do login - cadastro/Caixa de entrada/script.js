let inboxEmails = [
    {
        sender: 'remetente@exemplo.com',
        subject: 'Assunto Importante',
        body: 'Este é o corpo do e-mail importante.',
        important: true,
        unread: true,
        deleted: false
    },
    {
        sender: 'outro_remetente@exemplo.com',
        subject: 'Assunto Normal',
        body: 'Este é o corpo do e-mail normal.',
        important: false,
        unread: false,
        deleted: false
    }
];

let deletedEmails = [
    {
        sender: 'terceiro_remetente@exemplo.com',
        subject: 'E-mail Excluído',
        body: 'Este é o corpo do e-mail excluído.',
        important: false,
        unread: false,
        deleted: true
    }
];

function deleteEmail(section, event) {
    let emailList = section === 'inbox' ? inboxEmails : deletedEmails;
    const emailDiv = event.target.closest('.email');
    const emailIndex = Array.from(emailDiv.parentElement.children).indexOf(emailDiv);
    emailList[emailIndex].deleted = true;
    if (section === 'inbox') {
        const importantEmail = inboxEmails.splice(emailIndex, 1)[0];
        importantEmail.deleted = true;
        deletedEmails.unshift(importantEmail);
    }
    displayEmails();
}

function restoreEmail(section, event) {
    let emailList = section === 'inbox' ? inboxEmails : deletedEmails;
    const emailDiv = event.target.closest('.email');
    const emailIndex = Array.from(emailDiv.parentElement.children).indexOf(emailDiv);
    emailList[emailIndex].deleted = false;
    if (section === 'deleted') {
        const restoredEmail = deletedEmails.splice(emailIndex, 1)[0];
        restoredEmail.deleted = false;
        inboxEmails.unshift(restoredEmail);
    }
    displayEmails();
}

function displayEmails() {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('active');
    });

    const inboxSection = document.getElementById('inbox');
    inboxSection.classList.add('active');

    const inboxEmailsDiv = document.getElementById('inbox-emails');
    inboxEmailsDiv.innerHTML = '';

    inboxEmails.forEach((email, index) => {
        if (!email.deleted) {
            const emailDiv = createEmailDiv(email, 'inbox');
            inboxEmailsDiv.appendChild(emailDiv);
        }
    });

    const deletedEmailsDiv = document.getElementById('deleted-emails');
    deletedEmailsDiv.innerHTML = '';

    deletedEmails.forEach((email, index) => {
        if (email.deleted) {
            const emailDiv = createEmailDiv(email, 'deleted');
            deletedEmailsDiv.appendChild(emailDiv);
        }
    });
}

function createEmailDiv(email, section) {
    const emailDiv = document.createElement('div');
    emailDiv.classList.add('email');
    if (email.unread) {
        emailDiv.classList.add('unread');
    }
    emailDiv.innerHTML = `
        <p class="sender">${email.sender}</p>
        <p class="subject">${email.important ? '<strong>' + email.subject + '</strong>' : email.subject}</p>
        <p class="body">${email.body}</p>
        <button onclick="markImportant('${section}', event)">Marcar como Importante</button>
        <button onclick="deleteEmail('${section}', event)">Excluir</button>
    `;
    return emailDiv;
}

function markImportant(section, event) {
    let emailList = section === 'inbox' ? inboxEmails : deletedEmails;
    const emailDiv = event.target.closest('.email');
    const emailIndex = Array.from(emailDiv.parentElement.children).indexOf(emailDiv);
    emailList[emailIndex].important = !emailList[emailIndex].important;
    displayEmails();
}

function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    const section = document.getElementById(sectionId);
    section.classList.add('active');

    if (sectionId === 'inbox' || sectionId === 'deleted') {
        displayEmails();
    }
}

function showCompose() {
    showSection('compose');
}

function openEmail(emailDiv, section) {
    if (section === 'inbox' && emailDiv.classList.contains('unread')) {
        emailDiv.classList.remove('unread');
        const emailIndex = Array.from(emailDiv.parentElement.children).indexOf(emailDiv);
        inboxEmails[emailIndex].unread = false;
    }
}

function permanentlyDeleteEmail(event) {
    const emailDiv = event.target.closest('.email');
    const emailIndex = Array.from(emailDiv.parentElement.children).indexOf(emailDiv);
    deletedEmails.splice(emailIndex, 1);
    displayEmails();
}

displayEmails();
